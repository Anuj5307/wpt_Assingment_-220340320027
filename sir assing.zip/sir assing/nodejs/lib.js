exports.previousNumber = function previousNumber(x)
{
    let X = 100
    return X-= 1

}