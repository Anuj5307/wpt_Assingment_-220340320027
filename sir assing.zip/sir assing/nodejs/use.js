let lb = require('./lib')

console.log("The Previous number is"+" "+lb.previousNumber())

