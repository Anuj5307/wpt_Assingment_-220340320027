const mysql = require('mysql2')

const dbparams = {

    host: 'localhost',
    user: 'root',
    password: 'cdac',
    database: 'Hazaribagh',
    port: 3306

}

const conn = mysql.createConnection(dbparams)

let itemno = 5
let itemname = 'maggee'
let price = 35
let category = 'cooking'

conn.query('insert into item (itemno, itemname, price, category) values (?,?,?,?);', [itemno, itemname, price, category], 
(err, resl)=>{

    if(err)
    {

        console.log("Let see error")

    }else{

        console.log("inserted successful"+" "+resl.affectedRows)
    
    }
    

})

console.log('db working with npm')