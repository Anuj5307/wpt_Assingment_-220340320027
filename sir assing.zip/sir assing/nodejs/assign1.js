function previous(num)
{
return (num-1);
}
let x=previous(10);
console.log("previous number is=" +x);